Function ASConfig {
    return @{
        KEY  = 5
        NAME = 'Cesar Cipher (Encrypt/Decrypt)'
    }
}

Function ASMain {
    #https://github.com/mikepfeiffer/PowerShell
    function ConvertTo-CesarCipher() {
        param($String)

        begin {
            $sb = New-Object System.Text.StringBuilder
        }

        process {
            $String.ToCharArray() | %{
                $null = $sb.Append([char](([int][char]$_) +1))            
            }
        }

        end {
            $sb.ToString()
        }
    }

    function ConvertFrom-CesarCipher() {
        param($String)

        begin {
            $sb = New-Object System.Text.StringBuilder
        }

        process {
            $String.ToCharArray() | %{
                $null = $sb.Append([char](([int][char]$_) -1))            
            }
        }

        end {
            $sb.ToString()
        }
    }

    $text = Read-Host "Enter text do convert"
    Clear-Host
    if ((Read-Host "What do you want to do? (encrypt = e / decrypt = d / default: encrypt)") -eq 'd') {
        Clear-Host
        Write-Host "Plaintext: " -NoNewline -ForegroundColor Yellow
        ConvertFrom-CesarCipher $text | out-host
    } else {
        Clear-Host
        Write-Host "Ciphertext: " -NoNewline -ForegroundColor Yellow
        ConvertTo-CesarCipher $text | out-host
    }
}