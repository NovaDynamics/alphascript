﻿function ASConfig {
    return @{
        KEY  = 5
        NAME = 'Hello World'
    }
}

function ASMain {
    Write-Host "Hello World"
}